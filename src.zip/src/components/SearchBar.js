import React, { useState, useEffect } from "react";
import { useAppContext } from "./AppProvider";


const SearchBar = () => {
    const { PostApi, GetApi } = useAppContext();
    const [datalist, setDatalist] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    // useEffect(() => {
    //     getallProduct();
    // }, []);

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    return (
        <div className="header">
            <input
                type="text"
                value={searchTerm}
                onChange={handleSearchChange}
                placeholder="Search  Product"
                className="search-input"
            />
        </div>
    );
};

export default SearchBar;
