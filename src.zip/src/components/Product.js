import React, { useState, useEffect } from "react";
import SearchBar from "./SearchBar";
import { useAppContext } from "./AppProvider";
import { useNavigate } from "react-router-dom";

const Product = () => {
    const { PostApi, GetApi } = useAppContext();
    const [products, setProducts] = useState([]);

    const navigate = useNavigate();

    useEffect(() => {
        getallProduct();
    }, []);
     // Function to handle product click
     const handleProductClick = (id) => {
        navigate(`/ViewProduct`, { state: { productId: id } });
        console.log("Product ID:", id); 
    };

    const getallProduct = () => {
        const method = 'GET';
        const url = `/products`;
        const data = null;

        GetApi(method, url, data)
            .then((response) => {
                console.log(response, "Product List");
                setProducts(response.data); // Set the product data here
            })
            .catch((error) => {
                console.log("Error fetching product data:", error);
            });
    };

    return (
        <div>
            <SearchBar />
                <div className="container my-4">
                    <div className="row">
                        {products.map((product) => (
                            <div key={product.id} className="col-lg-3 col-md-4 col-sm-6 mb-4">
                                <div className="card h-100">
                                    <img src={product.image} className="card-img-top" alt={product.title} />
                                    <div className="card-body">
                                        <h5 className="card-title" onClick={() => handleProductClick(product.id)}>{product.title}</h5>
                                        <p className="card-text">₹ {product.price}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
        </div>
    );
};

export default Product;
