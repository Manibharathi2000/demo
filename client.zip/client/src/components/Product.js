import React, { useState, useEffect } from "react";
import SearchBar from "./SearchBar";
import { useAppContext } from "./AppProvider"; // Ensure your context is set up properly

const Product = () => {
    const { PostApi, GetApi } = useAppContext(); // assuming these are custom hooks
    const [products, setProducts] = useState([]);

    useEffect(() => {
        getallProduct();
    }, []);

    const getallProduct = () => {
        const method = 'GET';
        const url = `/products`;
        const data = null;

        GetApi(method, url, data)
            .then((response) => {
                console.log(response, "Product List");
                setProducts(response.data); // Set the product data here
            })
            .catch((error) => {
                console.log("Error fetching product data:", error);
            });
    };

    return (
        <div>
            <SearchBar />
                <div className="container my-4">
                    <div className="row">
                        {products.map((product) => (
                            <div key={product.id} className="col-lg-3 col-md-4 col-sm-6 mb-4">
                                <div className="card h-100">
                                    <img src={product.image} className="card-img-top" alt={product.title} />
                                    <div className="card-body">
                                        <h5 className="card-title">{product.title}</h5>
                                        <p className="card-text">₹ {product.price}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
        </div>
    );
};

export default Product;
