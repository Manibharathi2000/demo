export const logo = process.env.PUBLIC_URL + '/images/logo.png'; 

